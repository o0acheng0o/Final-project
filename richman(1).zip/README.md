# Bikini Bottom RICH MAN
JavaScript Beechcastle Monopoly, from Timeless Classics.

## Thinking

### HTML & CSS

- Configuration option box: Select money, Number of players, Computer staff
- Select Role box: Select a role
- Main map: through grid layout, dynamic addition of chess grid through JS; The large grid in the middle is used to store various game information, from top to bottom: current player, game options, dice area, player information area.
- Various components: character pieces, houses, animations for upgrading houses, purchase boxes, message boxes, property information cards.

### Start (initializing.js)

- Select a city
- Select the number of people
- Select a role
- Game start

### weather (weather.js)

- Request API to get weather information
- Update weather information


### progressive (monopoly.js)

#### Main line

- Roll the dice.
- Character moves according to setInterval of dice count
- setTimeout Triggers the chess event after stopping
- Turn to the next player after the event is completed

#### Other

- Handle land purchases and property upgrades
- Determine player order (avoid stops and bankruptcies)
- Judge the player bankrupt
- Judge the game over

### data (Data.js)

- Character pieces
- Name.
- Money.
- Status (active or bankrupt)
- Stop (number of days, default is 0)
- Whether the player controls
- Corresponds to the DOM node
- Currently in chess position
- Chess.
- Place names.
- Land price.
- Status (corresponding to the class of ordinary estate or special area)
- Corresponds to the DOM node
- Chance and fate.
- Description text
- Monetary value
- Stop or not.

### DOM operation (DOM-binding.js)

- Display related content on the interface