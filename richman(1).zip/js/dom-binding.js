/*
 * Dom-related operations
 */
// Shortcut Dom
var map = document.querySelector('.map')
var dice = document.querySelector(".dice")
var choosebox = document.querySelector(".choosebox")
var choosechr = document.querySelector(".choosechr")
var title = document.querySelector(".title")
var info = document.querySelector('.info')
var dialog = document.querySelector(".dialog")
var infobox = document.querySelector(".infobox")
var msgbox = document.querySelector(".msgbox")
var audio = document.querySelector(".audio")
var headerTitle = document.querySelector(".headerTitle")
var roles = document.querySelector(".roles")

// Displays a list of role selections  
setRoles()
// Create a function to animate the building construction  
function construct() {
	// Create a new div element to hold the building images  
	let constructDiv = document.createElement('div');
	// Set the class name of the div element to 'construct'  
	constructDiv.className = 'construct';

	// Loop to add images  
	for (let i = 0; i < 5; i++) {
		// Create a new img element  
		const img = document.createElement('img');
		// Set the source path of the img element, assuming there are 5 images from c1.png to c5.png  
		img.src = `./public/img/c${i + 1}.png`;
		// Append the img element to the construct div  
		constructDiv.append(img);
	}

	// Return the construct div element containing all the images  
	return constructDiv;
}
// Create an upgraded house image based on the index  
function buildings(index) {
	// Create a new img element  
	let img = document.createElement('img');

	// Set the source of the img element based on the index  
	// Assuming there are images named l1.png, l2.png, etc. in the ./public/img/ directory  
	img.src = `./public/img/l${index + 1}.png`;

	// Set the class name of the img element to 'house'  
	img.className = 'house';

	// Return the img element  
	return img;
}

// Write map tiles  
for (let i = 0; i < 30; i++) {
	// Create a new div element to represent a map tile  
	let box = document.createElement('div');

	// Create a new h3 element to potentially hold tile information (although it's empty in this snippet)  
	let h3 = document.createElement('h3');

	// Set the class name of the div element to 'box'  
	box.className = 'box';

	// Append the h3 element to the div element  
	box.append(h3);

	// Prepend the div element (which represents a map tile) to the 'map' container  
	map.prepend(box);
}

// Bind selection events  
// Convert the NodeList returned by querySelectorAll into an array  
Array.from(document.querySelectorAll('.choosebox li')).forEach((node, index) => {
	// Add a click event listener to each li element  
	node.addEventListener('click', () => {
		// When the li element is clicked, call the chooseNumber function and pass the index as an argument  
		chooseNumber(index);
	});
});
// Update the DOM display when selection configuration changes  
function writeSetting(title, startNum, num) {
	// Set the inner HTML of the first child element of 'choosebox' to the provided title  
	choosebox.firstElementChild.innerHTML = title;

	// Iterate through all the child elements of the last child element of 'choosebox'  
	Array.from(choosebox.lastElementChild.children).forEach((node, index) => {
		// Set the inner HTML of each node to the start number plus its index  
		node.innerHTML = startNum + index;

		// Based on the value of 'num', perform different actions on the nodes  
		switch (num) {
			case 3:
				// If 'num' is 3, call the function to finalize the choice  
				finishChooseNumber();
				break;
			case 2:
				// If 'num' is 2, disable all nodes with index greater than 1  
				if (index > 1) {
					disableBox(node);
				}
				break;
			case 1:
				// If 'num' is 1, disable all nodes with index greater than 2  
				if (index > 2) {
					disableBox(node);
				}
				break;
			case 0:
				// If 'num' is 0, disable the node with index less than 1 (although this condition is never true since indices start at 0)  
				// This case seems incorrect and should probably be modified or removed  
				if (index < 1) {
					disableBox(node);
				}
				break;
		}
	});
}
// Disable the box to avoid the total number of people exceeding four  
function disableBox(node) {
	node.style.pointerEvents = "none"; // Disables click events on the node  
	node.style.background = "grey";     // Changes the background color to grey  
}

// Finish number selection, enable character selection, and display the map  
function finishChooseNumber() {
	choosebox.style.display = "none";   // Hides the number selection box  
	choosechr.style.display = "block";  // Shows the character selection box  
}

// Create a reusable arrow element  
// Create a reusable arrow  
let arrow = document.createElement('div');
arrow.className = 'arrow';              // Set the class name for the arrow  
let img = document.createElement('img');
img.src = "./public/img/arrow.png";     // Set the image source for the arrow  
arrow.append(img);                     // Append the image to the arrow  

// Character selection logic  
Array.from(choosechr.lastElementChild.children).forEach(item => {
	// Add event listener for mouseover on the first child element (likely a character image)  
	item.firstElementChild.addEventListener('mouseover', function () {
		// Append the arrow to the item on mouseover  
		item.appendChild(arrow);
	});

	// Add event listener for click on the first child element  
	item.firstElementChild.addEventListener('click', () => {
		// Handle the selected effect  
		item.firstElementChild.style.border = "1px solid #666"; // Add a border to indicate selection  

		// Create a div to display the index  
		let index = document.createElement('div');
		index.innerHTML = `${players.length + 1}`;              // Set the index based on the current number of players  
		index.className = 'index';                              // Set the class name for the index  
		item.appendChild(index);                                // Append the index to the item  

		// Remove the arrow  
		item.removeChild(arrow);

		// Disable click events on the item  
		item.style.pointerEvents = "none";

		// Create a pawn corresponding to the character  
		let name = item.children[1].innerHTML;                   // Get the character name  
		let node = document.createElement('img');
		node.className = `chr chr-${name.replace(' ', '')}`;     // Set the class name for the pawn, removing spaces  
		node.src = `./public/img/${name}.png`;                   // Set the image source for the pawn  
		places[0].node.append(node);                            // Append the pawn to the game board  

		// Handle character-specific logic  
		binding(node, name); // Assuming this is a function to handle binding logic  
	});
});
// Start the game  
function gameStart() {
	// Hide the character selection area  
	choosechr.parentElement.style.display = "none";
	// Show the header title  
	headerTitle.style.display = "block";
	// Make the title visible  
	title.style.visibility = "visible";
	// Write game information  
	writeInfo();
	// Place initial information  
	placeInfo();
	// Update the current player's name  
	updatePlayer(players[s].name);
	// Set the first player as the current player  
	person = players[0];
}

// # UI Display Related  

// Dice rolling area  
// Add a click event listener to the dice to start the game  
dice.addEventListener("click", () => {
	game(); // Assuming game() is a function that handles the game logic  
});

// Roll the dice  
function rollDice(num) {
	// Generate a random number between 1 and 2 (likely for dice sides)  
	let bg = generateNum(1, 2);
	// Set the dice background image based on the random number  
	dice.style.background = `url(./public/img/s${bg}.jpg)`;
	// After 300ms, change the dice background to the specified number  
	setTimeout(function () {
		dice.style.background = `url(./public/img/${num}.jpg)`;
	}, 300);
	// Toggle the dice's clickability  
	toggleDice(false);
}

// Toggle the dice's clickability  
function toggleDice(state) {
	if (state) {
		// Enable click events on the dice  
		dice.style.pointerEvents = "auto";
	} else {
		// Disable click events on the dice  
		dice.style.pointerEvents = "none";
	}
}

// Game information area
// Update the current active player  
function updatePlayer(name) {
	let playerInfos = document.querySelectorAll('.info > div')
	playerInfos.forEach(node => {
		// Reset the background color of all player info nodes  
		node.style.backgroundColor = '';
		// If the node's class matches the current player's name, update its background color  
		if (node.className === "info-" + name) {
			node.style.backgroundColor = 'rgba(243,129,17, 0.3)';
		}
	});
}

// Update the current round number  
function updateRound() {
	let num = +document.querySelector('.big-box span b').innerHTML + 1;
	document.querySelector('.big-box span b').innerHTML = num;
}

// Display player information  
function writeInfo() {
	let num = playerNumber + npcNumber;
	for (let i = 0; i < num; i++) {
		let node = document.createElement('div');
		node.className = 'info-' + players[i].name;
		let img = document.createElement('img');
		img.src = `./public/img/${players[i].name}.png`;
		let h2 = document.createElement('h2');
		let h3 = document.createElement('h3');
		h3.innerHTML = `$${players[i].money}`; // Assuming this is intended to display the money with two dollar signs  
		h2.innerHTML = players[i].name;
		h2.style.color = colorScheme[players[i].name]; // Assuming colorScheme is an object mapping player names to colors  
		node.append(img);
		node.append(h3);
		node.append(h2);
		info.append(node); // Assuming info is a reference to a container element  
	}
}

// Update the real-time money display  
function updateInfo() {
	let num = playerNumber + npcNumber;
	for (let i = 0; i < num; i++) {
		info.children[i].firstElementChild.nextElementSibling.innerHTML = "$" + players[i].money;
	}
}

// Move the character out of play when they become bankrupt  
function updateBankrupt(node, index, name) {
	info.children[index].style.backgroundImage = `url(./public/img/over.png)`;
	// Using jQuery to hide the character's image   
	$(`.chr-${name.replace(' ', '')}`).hide(); // Assuming this is a jQuery selector to hide the character's image  
}

// Display property ownership  
function buyPlace(node, color, name) {
	// Create an h2 element to display the name of the property  
	let h2 = document.createElement('h2');
	h2.innerHTML = name;
	h2.style.background = color; // Set the background color of the h2 element  
	h2.className = `box-${name.replace(' ', '')}`; // Assign a class name to the h2 element based on the name  
	node.append(h2); // Append the h2 element to the node  
	node.style.boxShadow = `3px 3px 3px inset ${color}, 3px -3px 3px inset ${color}, -3px 3px 3px inset ${color}, -3px -3px 3px inset ${color}`; // Add a box shadow to the node using the provided color  
}

// Display building upgrade animation  
function upgradeHouse(node, state) {
	// Create the upgrade animation element  
	let upgrade = construct(); // Assuming 'construct' is a function that returns the upgrade animation element  
	node.prepend(upgrade); // Prepend the upgrade animation element to the node  

	// After 2 seconds, remove the upgrade animation and display the new building  
	setTimeout(() => {
		node.removeChild(upgrade); // Remove the upgrade animation element  
		node.append(buildings(state)); // returns the new building element based on the state  
		gameSequence(s); // Assuming 'gameSequence' is a function to handle the game sequence, and 's' is a relevant parameter  
	}, 2000);
}

// Display property information  
function placeInfo() {
	places.forEach(place => { // Loop through each property  
		place.node.addEventListener('mouseover', () => { // Add a mouseover event listener to the property's node  
			if (place.state >= 0) { // Check if the property has a valid state  
				infobox.style.display = "block"; // Show the info box  
				infobox.firstElementChild.innerHTML = place.name; // Set the property name in the info box  
				infobox.lastElementChild.children[0].innerHTML = `Owner: ${place.owner}`; // Set the property owner in the info box  
				infobox.lastElementChild.children[1].innerHTML = `Value: ${place.value}`; // Set the property value in the info box  

				if (place.owner) { // If there is an owner  
					let state = 5 / (place.state * 3 + 1); // Calculate the state factor  
					let cost = place.value / (state > 0.5 ? Math.ceil(state) : state); // Calculate the cost based on the state  
					infobox.lastElementChild.children[2].innerHTML = `Rent: ${cost}`; // Set the rent cost in the info box  
				} else {
					infobox.lastElementChild.children[2].innerHTML = ""; // If there's no owner, clear the rent cost  
				}
			} else {
				return; // If the property state is invalid, do nothing  
			}
		});

		place.node.addEventListener('mouseout', () => { // Add a mouseout event listener to the property's node  
			infobox.style.display = "none"; // Hide the info box when the mouse leaves the property  
		});
	});
}

// Display a message box  
function showMsgbox(msg) {
	msgbox.style.display = "block"; // Show the message box  
	msgbox.innerHTML = msg; // Set the message in the message box  

	// After a certain delay (assuming 'v' is a variable representing the delay factor), hide the message box  
	setTimeout(() => {
		msgbox.style.display = "none";
	}, v * 1.6);
}

// Show the purchase dialog  
function showDialog(type, allowButton) {  
	// Display the dialog  
	dialog.style.display = 'block';  
  
	// Initialize title and message variables  
	let title, msg;  
  
	// Extract the necessary properties from the current position in places  
	let { name, value, state } = places[person.position];  
  
	// Set the title and message based on the type  
	if (type === "purchase") {  
		title = "Purchase Property";  
		msg = `Are you sure you want to spend $${value * (state + 1)} to purchase ${name}?`;  
	} else {  
		title = "Upgrade Property";  
		msg = `Are you sure you want to spend $${value / 2} to upgrade ${name}?`;  
	}  
  
	// Set the title of the dialog  
	dialog.children[1].innerHTML = title;  
  
	// Set the message of the dialog  
	dialog.firstElementChild.innerHTML = msg;  
  
	// Enable or disable the button based on allowButton  
	if (allowButton) {  
		dialog.children[2].style.pointerEvents = "auto";  
		dialog.children[2].style.background = "#f2f2f2";  
	} else {  
		dialog.children[2].style.pointerEvents = "none";  
		dialog.children[2].style.background = "#454545";  
	}  
  
	// Set the click event for the confirm button  
	dialog.children[2].onclick = () => { // Confirm button  
		dialogClicked(type, true);  
	};  
}  
  
// Add a click event listener for the cancel button   
dialog.children[3].addEventListener('click', () => {  
	// Cancel button click event 
	dialogClicked("", false);  
});  
  
// Close the purchase dialog  
function closeDialog() {  
	// hidden dialog
	dialog.style.display = "none";  
}  
  
// Toggle the instructions and set the area/section  
// Toggle instructions  
document.querySelectorAll('.big-box button')[0].addEventListener('click', function () {  
	// Check if the button text is "规则介绍" (Rule Introduction)  
	if (this.innerHTML === "Rule introduction") {  
		// Change the button text to "Return"  
		this.innerHTML = "Return";  
		// Set the height of the instruction container to 100%  
		document.querySelector('.instruction').style.height = "100%";  
	} else {  
		// Change the button text back to "规则介绍" (Rule Introduction)  
		this.innerHTML = "Rule introduction";  
		// Set the height of the instruction container to 0  
		document.querySelector('.instruction').style.height = "0";  
	}  
});  
  
// Toggle speed  
document.querySelectorAll('.big-box button')[1].addEventListener('click', function () {  
	// Determine the text for the speed button based on the current speed variable  
	let text = v > 600 ? 'Normal' : 'Fast';  
	// Set the text of the speed button  
	this.innerHTML = `${text} Speed`;  
	// Toggle the speed variable  
	v = 1300 - v;
});  
  
// Toggle auto-play/management  
document.querySelectorAll('.big-box button')[2].addEventListener('click', function () {  
	// Check if the button text is "Open hosting" (Enable Auto-Management)  
	if (this.innerHTML === "Open hosting") {  
		// Change the button text to "Close hosting" (Disable Auto-Management)  
		this.innerHTML = "Close hosting";  
		// Iterate through all players and disable auto-management if enabled  
		players.forEach(player => {  
			if (player.control) {  
				player.control = "";  
			}  
		});  
	} else {  
		// Change the button text back to "Open hosting" (Enable Auto-Management)  
		this.innerHTML = "Open hosting";  
		// Iterate through all players and enable auto-management if not enabled  
		players.forEach(player => {  
			if (!player.control) {  
				player.control = 1;  
			}  
		});  
	}  
});  
  
// Toggle audio play/pause  
document.querySelectorAll('.audiobtn')[0].addEventListener('click', function () {  
	// Determine the audio state based on whether the audio is paused  
	let audioState = audio.paused ? "Play" : "Pause";  
	// If the audio is paused, play it and change the button text to "Mute" (Mute)  
	if (audioState === 'Play') {  
		audio.play();  
		this.innerHTML = "Mute";  
	} else {  
		// If the audio is playing, pause it and change the button text to "Music" (Music)  
		audio.pause();  
		this.innerHTML = "Music";  
	}  
});

// Displays a list of role selections  
function setRoles() {  
	let html = '' // Initialize an empty string to store the HTML for the role list  
  
	// Iterate through each role in the roleList array  
	roleList.forEach(role => {  
		// Construct the HTML for each role item  
		html += `  
		<li>  
			<!-- Insert an image with the class 'middle' and the source based on the role name -->  
			<img class="middle" src="./public/img/${role}.png" alt="">  
			<!-- Insert a heading with the role name -->  
			<h3>${role}</h3>  
		</li>  
		`  
	})  
  
	// Set the innerHTML of the 'roles' element to the constructed HTML  
	roles.innerHTML = html // Populate the role selection list with the generated HTML  
}  
  
// Create grid cells    
placeList.forEach(place => {  
	// Create a new 'CreateBox' instance, passing the 'place' object as arguments (using spread operator)  
	new CreateBox(...place) // Instantiate a new box for each place in the placeList array  
})
