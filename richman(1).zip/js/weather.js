/*
 * City, weather related codes
 */
// Get the value of the 'province' item from localStorage and assign it to the provinceValue variable  
let provinceValue = localStorage.getItem('province');  
  
// Get the value of the 'city' item from localStorage and assign it to the cityValue variable  
let cityValue = localStorage.getItem('city');  
  
// Initialize the provinceIndex variable to 0, which may be used for subsequent selection or processing  
let provinceIndex = 0;  
  
// Get the value of the 'cityText' item from localStorage and assign it to the cityText variable  
// This value might be the full text description of a city  
let cityText = localStorage.getItem('cityText');

// Set a function to run when the window is fully loaded  
window.onload = function () {  
  
    // Select the element with the class 'choosecity'  
    let choosecity = document.querySelector(".choosecity");  
  
    // Select the element with the class 'choosebox'  
    let choosebox = document.querySelector(".choosebox");  
  
    // Select the element with the id 'province'  
    let provinceSelect = document.getElementById('province');  
  
    // Select the element with the id 'city'  
    let citySelect = document.getElementById('city');  
  
    // Redundant line, as it is duplicating the previous line (but kept for clarity)  
    let province = document.getElementById('province');  
  
    // Redundant line, as it is duplicating the previous line (but kept for clarity)  
    let city = document.getElementById('city');  
  
    // Select the element with the id 'address' or create an empty object if not found  
    let address = document.getElementById('address') || {};  
  
    // Add a '请选择' (Please choose) option to the beginning of the provinces array  
    provinces.unshift({ name: '请选择', pinyin: 'please choose', cities: [] });  
  
    // Iterate through the provinces array  
    provinces.forEach((province, index) => {  
        // Create a new option element  
        let option = document.createElement('option');  
        // Set the value of the option to the province name  
        option.value = province.name;  
        // Set the displayed text of the option to the pinyin  
        option.text = province.pinyin;  
        // Append the option to the provinceSelect element  
        provinceSelect.appendChild(option);  
  
        // If the current province name matches the saved provinceValue  
        if (province.name === provinceValue) {  
            // Set the provinceIndex to the current index  
            provinceIndex = index;  
        }  
    });  
  
    // Add an event listener to the provinceSelect element for changes  
    provinceSelect.onchange = function () {  
        // Get the selected index of the provinceSelect  
        let provinceIndex = provinceSelect.selectedIndex;  
        // Populate the citySelect with cities based on the selected province  
        populateCity(citySelect, provinceIndex);  
    };  
  
    // Event listener for the submitcity button  
    // Confirm the address selection  
    document.getElementById('submitcity').addEventListener('click', () => {  
        // Save the selected province to localStorage  
        localStorage.setItem('province', province.value);  
        // Save the selected city to localStorage  
        localStorage.setItem('city', city.value);  
        // Get the text of the selected city option  
        // cityText = citySelect.querySelector("option:checked").text;  
        cityText = citySelect.options[citySelect.selectedIndex].text;
        // Save the city text to localStorage  
        localStorage.setItem('cityText', cityText);  
        // Save the address to localStorage  
        localStorage.setItem('address', address.value);  
        // Hide the choosecity element  
        choosecity.style.display = 'none';  
        // Show the choosebox element  
        choosebox.style.display = 'block';  
        // Get the weather for the selected city  
        getWeather(city.value, cityText);  
    });  
  
    // After a delay of 1000 milliseconds (1 second)  
    setTimeout(() => {  
        // If a provinceIndex is set  
        if (provinceIndex) {  
            // Populate the citySelect with cities based on the saved provinceIndex  
            populateCity(citySelect, provinceIndex);  
            // Set the value of the provinceSelect to the saved provinceValue  
            provinceSelect.value = provinceValue;  
        } else {  
            // Otherwise, populate the citySelect with cities for the default province (index 0)  
            populateCity(citySelect, 0); // Default to no city selected  
        }  
        // Set the value of the address element to the saved address from localStorage, or an empty string if not found  
        address.value = localStorage.getItem('address') || '';  
    }, 1000);  
  
};

// Function to create rain effect using horizontal rules (HR)  
function rainFunction(counter = 10) {  
    let hrElement; // Declare a variable to hold the HR element  
  
    // Loop to create multiple HR elements  
    for (let i = 0; i < counter; i++) {  
        hrElement = document.createElement("HR"); // Create a new HR element  
  
        // If it's the last HR, give it a special class name  
        if (i == counter - 1) {  
            hrElement.className = "thunder"; // Assign a class name for thunder effect  
        } else {  
            // For other HR elements, set random styles  
            hrElement.style.left = Math.floor(Math.random() * window.innerWidth) + "px"; // Set random left position  
            hrElement.style.animationDuration = 0.2 + Math.random() * 0.3 + "s"; // Set random animation duration  
            hrElement.style.animationDelay = Math.random() * 5 + "s"; // Set random animation delay  
        }  
  
        // Append the HR element to the body  
        document.body.appendChild(hrElement);  
    }  
}  
  
// Function to populate city options in a select element based on a province index  
function populateCity(citySelect, provinceIndex) {  
    // Clear all existing options from the select element  
    citySelect.options.length = 0; // Empty the options  
  
    // If a valid province index is provided  
    if (provinceIndex >= 0) {  
        // Iterate through the cities of the selected province  
        provinces[provinceIndex].cities.forEach(city => {  
            // Create a new option element  
            let option = document.createElement('option');  
            // Set the value of the option to the city name  
            option.value = city.name;  
            // Set the displayed text of the option to the city's pinyin  
            option.text = city.pinyin;  
            // Append the option to the select element  
            citySelect.appendChild(option);  
  
            // If the current city matches a specified city value  
            if (cityValue == city.name) {  
                // Set the selected city in the select element  
                citySelect.value = city.name;  
            }  
        });  
    }  
}
// const res = {
//     "wea": "大雨",
//     "tem": "20",
//     "win": "东风",
//     "win_speed": "3-4级",
//     "win_meter": "小于10km/h"
// }

// Request API to get weather data
function getWeather(cityName = '', cityText) {  
    // If no city name is provided, return immediately  
    if (!cityName) {  
        return;  
    }  
  
    // Get the first DOM element with the class 'weather'  
    let weatherDom = document.getElementsByClassName('weather')[0];  
  
    // Remove the '市' character from the city name (if present)  
    cityName = cityName.replace(/市/g, '');  
    console.log(cityName); // Log the modified city name  
  
    // Construct the URL to fetch weather data  
    let url = `https://v1.yiketianqi.com/free/day?appid=77243836&appsecret=2nLkkZ3x&unescape=1&city=${cityName}`;  
  
    // Make a GET request to the weather API  
    $.get(url, function (res) {  
        // 'res' contains the data returned by the server  
  
        // Set random events based on the weather  
        setFatesByWeather(res.wea);  
        // Set the background based on the weather condition 
        setBackgroundByWeather(res.wea);  
  
        // Determine the image name based on the weather condition  
        let imgName = `default`;  
        switch (res.wea) {  
            case '晴':  
                imgName = 'sunny';  
                break;  
            case '多云':  
                imgName = 'cloudy';  
                break;  
            case '阴':  
                imgName = 'overcast';  
                break;  
            case '小雨':  
                imgName = 'lightRain';  
                break;  
            case '雷阵雨':  
                imgName = 'thunderShower';  
                break;  
            case '风':  
                imgName = 'wind';  
                break;  
        }  
  
        // Update the weather DOM with the fetched data  
        weatherDom.innerHTML = `  
            <span>${cityText}</span> 
            <span>${getDay()}</span> 
            <img src="./public/img/${imgName}.png" alt="">  
            <span>${res.tem}℃</span>  
            <span>${res.win}</span>  
        `;  
    }).fail(function (jqXHR, textStatus, errorThrown) {  
        // Handle the case when the GET request fails  
        console.log('GET request failed, error message：' + textStatus);  
    });  
}

// Set the background based on the weather condition  
function setBackgroundByWeather(wea = ''){  
    // Get the first <body> element from the document  
    let body = document.getElementsByTagName('body')[0];  
  
    // If the weather includes '大雨' (heavy rain)  
    if(wea.includes('大雨')){  
        // Call the rainFunction with a parameter of 100 (assuming this controls the intensity)  
        rainFunction(100);  
    }  
    // If the weather includes '中雨' (moderate rain)  
    else if(wea.includes('中雨')){  
        // Call the rainFunction with a parameter of 50  
        rainFunction(50);  
    }  
    // If the weather includes '雨' (rain in general)  
    else if(wea.includes('雨')){  
        // Call the rainFunction with a parameter of 20  
        rainFunction(20);  
    }  
  
    // If the weather includes '大风' (strong wind)  
    if(wea.includes('大风')){  
        // Set the background image to gale.gif  
        body.style.backgroundImage = "url(./public/img/gale.gif)";  
    }  
    // If the weather includes '风' (wind in general)  
    else if(wea.includes('风')){  
        // Set the background image to wind.gif  
        body.style.backgroundImage = "url(./public/img/wind.gif)";  
    }  
  
    // If the weather includes '晴' (sunny)  
    if(wea.includes('晴')){  
        // Set the background image to fine.png  
        body.style.backgroundImage = "url(./public/img/fine.png)";  
    }  
  
    // If the weather includes '阴' (cloudy or overcast)  
    if(wea.includes('阴')){  
        // Set the background image to yin.png  
        body.style.backgroundImage = "url(./public/img/yin.png)";  
    }  
  
    // If the weather includes '雷' (thunder)  
    if(wea.includes('雷')){  
        // Set the background image to thundery.gif  
        body.style.backgroundImage = "url(./public/img/thundery.gif)";  
    }  
  
    // If the weather includes '云' (cloudy)  
    if(wea.includes('云')){  
        // Set the background image to cloudy_bg.png  
        body.style.backgroundImage = "url(./public/img/cloudy_bg.png)";  
    }  
}

// Set random events based on the weather  
function setFatesByWeather(wea) {  
    const weatherFates = [] // Initialize an array to store weather-based events  
  
    switch (wea) { // Use a switch statement to handle different weather conditions  
        case '晴':  
            // Sunny weather  
            weatherFates.push(  
                // Good event: Earned money from a part-time job  
                ['It was sunny today. I earned $200 from my part-time job', 200, 0],  
                // Bad event: Had to spend money to go out  
                [`It's sunny today. It costs $500 to go out`, -500, 0]  
            )  
            break;  
  
        case '多云':  
            // Cloudy weather  
            weatherFates.push(  
                // Bad event: Income reduced due to cloudy weather  
                ['Today the weather is cloudy, remember to take an umbrella when you go out, the income is reduced by $500', -500, 0]  
            )  
            break;  
  
        case '阴':  
            // Overcast weather  
            weatherFates.push(  
                // Bad event: Fine for not working  
                [`It's cloudy today, sleep at home and forget to work, fine $300`, -300, 0]  
            )  
            break;  
  
        case '小雨':  
            // Light rain  
            weatherFates.push(  
                // Bad event: Fine for not working  
                ['Light rain today, sleep at home and forget to work, fine $300', -300, 0]  
            )  
            break;  
  
        case '雷阵雨':  
            // Thunderstorm  
            weatherFates.push(  
                // Bad event: Income reduction due to not being able to work  
                ['Thunderstorm, can not go out to work, income reduction of $500', -500, 0]  
            )  
            break;  
  
        case '风':  
            // Windy weather  
            weatherFates.push(  
                // Good event: Income increased due to drying laundry  
                [`It's windy today. Dry the laundry on the balcony. Increase your income by $300`, 300, 0],  
                // Bad event: Savings reduced due to wind blowing away money  
                ['Today, the wind blew away the private money on the balcony, and the savings were reduced by $100', -100, 0]  
            )  
            break;  
    }  
  
    // Iterate over the weather-based events and create new fates  
    weatherFates.forEach(item => {  
        new CreateFate(...item) // Assuming CreateFate is a constructor that takes these parameters  
    })  
}





