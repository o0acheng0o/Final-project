/*  
 * Game Initialization  
 */  
  
// Initialize player's turn sequence  
var s = 0; /* sequence */  
// Initialize player count  
var playerNumber = 0; /* number of players */  
// Initialize npc count  
var npcNumber = 0; /* number of npc */  
// Initialize money  
var startMoney = 0; /* initial money */  
// Initialize speed  
var v = 800; /* initial speed */  
// Initialize current player (declared but not assigned yet)  
var person; /* current player */  
  
  
  
// Function to choose configuration  
function chooseNumber(num) { /* choose configuration */  
	if (!startMoney) { /* choose starting money */  
		writeSetting("Number of players", 1);  
		startMoney = num * 5000 + 10000;  
	} else if (!playerNumber) { /* choose player count */  
		writeSetting("Computer staff", 0, num);  
		playerNumber = +num + 1;  
	} else { 
		// choose npc count
		npcNumber = +num;  
		// Finish number selection, enable character selection, and display the map 
		finishChooseNumber();  
	}  
}  
  
// Function for character selection  
function binding(node, name) { /* character selection */  
	// Check if it's player or computer controlled  
	let control = players.length < playerNumber ? 1 : 0; /* player or computer control */  
	// Create a player  
	new CreatePlayer(name, players.length, startMoney, "active", 0, control, node);  
	// Check if all players (including npc) are selected  
	if (players.length == (playerNumber + npcNumber)) { 
		// game start
		gameStart();  
	}  
}