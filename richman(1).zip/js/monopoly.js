/*  
 * Game logic processing  
 */
// Dice rolling sequence  
function gameSequence(index) {
	// If the current index is the last player, reset to the first player and update the round  
	if (index === (playerNumber + npcNumber) - 1) { /* From the last player to the first player */
		index = 0;
		updateRound(); /* Update the round status */
	} else { // Move to the next player  
		index++;
	}

	// Use setTimeout to simulate the delay in rolling the dice  
	// and call the function recursively if the next player is available  
	setTimeout(() => {
		// Check the state of the next player: if not available (false), continue rolling  
		if (!checkPlayerState(index)) { /* Check the state of the next player: if false, continue rolling the dice */
			gameSequence(index);
		}
	}, v); /* v is presumably a variable representing the delay in milliseconds */
}

// Function to move a player one step  
function playerMove(index) {

	// If the player is at the end of the track (position 29)  
	if (person.position === 29) {
		// Reset the player's position to the start (-1)  
		person.position = -1;
		// Append the player's node to the start position's node  
		places[0].node.append(players[index].node);
		// Update the game information or UI  
		updateInfo();
		// Add 1000 money to the player's total  
		players[index].money += 1000;
	}

	// Increment the player's position  
	person.position++;
	// Append the player's node to the new position's node  
	places[person.position].node.append(players[index].node);
}

// Function to handle the game logic from rolling the dice to the action completion  
function game() {
	// Display the dice roll number  
	let num = generateNum(1, 6); // Generate a number between 1 and 6 for the dice roll  
	rollDice(num); // Show the dice roll animation or result  

	// Bind the corresponding player  
	person = players[s]; // Assume 's' is the current player's index  

	// Set an interval to move the player to the next square based on their speed  
	let move = setInterval(() => {
		playerMove(s); // Move the player to the next square  
	}, v); // Assume 'v' is the interval speed in milliseconds  

	// After a set time, stop the player's movement and trigger the square's event  
	setTimeout(() => {
		clearInterval(move); // Stop the movement interval  

		let place = places[person.position]; // Get the square the player landed on  

		// Purchase property (involves asynchronous behavior)  
		if (!place.owner) { // If the property is not owned  
			if (person.control) { // If the player has control (is a human player)  
				showDialog("purchase", person.money > place.value); // Show a dialog to purchase the property if the player has enough money  
			} else { // NPC behavior  
				// Wait for a short time and then decide to purchase if they have over 3000 after the purchase  
				setTimeout(() => dialogClicked("purchase", (person.money - place.value) > 3000), v / 3);
			}
		} else if (place.owner && place.owner !== person.name && place.owner !== "sean") { // If the property is owned and not by the current player or a special area  
			let owner = players.find(player => player.name === place.owner); // Find the owner of the property  

			if (owner.stop) { // If the owner is not at home  
				showMsgbox("The house owner is not here, free lodging for the night!");
			} else { // Pay rent  
				let state = 5 / (place.state * 3 + 1); // Calculate the rent based on the property's state  
				let cost = place.value / (state > 0.5 ? Math.ceil(state) : state); // Calculate the rent amount  
				person.money -= cost;
				owner.money += cost;
				showMsgbox(`${owner.name} thanks ${person.name} for spending $${cost} at ${place.name}`);
				checkBankrupt(); // Check if the player went bankrupt  
			}

			gameSequence(s); // Move to the next player's turn  
		} else if (place.owner === person.name) { // Upgrade property (involves asynchronous behavior)  
			if (place.state === 3) {
				gameSequence(s); // Cannot upgrade further, move to the next player's turn  
			} else {
				if (person.control) { // Player control  
					showDialog("upgrade", person.money > place.value * 0.5); // Show a dialog to upgrade the property if the player has enough money  
				} else { // NPC behavior  
					// Upgrade if they have over 2000 after spending half the property's value  
					dialogClicked("upgrade", (person.money - place.value / 2) > 2000);
				}
			}
		} else if (place.state === "goodEvent") { // Found money  
			let randomMoney = 500 * generateNum(0, 7);
			person.money += randomMoney;
			showMsgbox(`Congratulations, you found $${randomMoney}`);
			gameSequence(s); // Move to the next player's turn  
		} else if (place.state === "badEvent") { // Pay taxes  
			let randomMoney = 300 * generateNum(0, 7);
			person.money -= randomMoney;
			showMsgbox(`You need to pay taxes to the government of $${randomMoney}`);
			checkBankrupt(); // Check if the player went bankrupt  
			gameSequence(s); // Move to the next player's turn  
		} else if (place.state === "jail") { // If the player lands on a jail square    
			// Generate a random number between 1 and 3 to determine the number of days in jail  
			person.stop = generateNum(1, 3)  
			// Show a message box indicating that the player was caught for tax evasion and will be imprisoned for a certain number of days  
			showMsgbox(`Caught for tax evasion, imprisoned for ${person.stop} days`)  
			// Continue with the game sequence  
			gameSequence(s)  
		}   
		// If the player lands on a casino square  
		else if (place.state === "casino") {  
			// Generate a random number between 1 and 6 (simulating a dice roll)  
			let num = generateNum(1, 6)  
			// Simulate rolling the dice with the generated number  
			rollDice(num)  
			// After a delay (v * 2), execute the following block of code  
			setTimeout(() => {  
				// Calculate the amount of money won based on the dice roll  
				let casinoMoney = num * 500  
				// Add the winnings to the player's money  
				person.money += casinoMoney  
				// Show a message box congratulating the player on their winnings  
				showMsgbox(`Congratulations, you won $${casinoMoney}`)  
				// Update the game information  
				updateInfo()  
				// Continue with the game sequence  
				gameSequence(s)  
			}, v * 2)  
			// toggleDice(true) // This line is commented out, presumably to toggle the dice visibility, but it's not being used here  
		}   
		// If the player lands on a surprise square (related to asynchronous behavior)  
		else if (place.state === "surprise") {  
			// Generate a random event index from the fates array  
			var event = generateNum(0, fates.length)  
			// Add the value of the event to the player's money  
			person.money += fates[event].value  
			// If the event involves imprisonment  
			if (fates[event].stop) {  
				// After a delay (v * 1.5), execute the following block of code  
				setTimeout(function () {  
					// Set the player's position to the jail square  
					person.position = 11  
					// Set the number of days in jail based on the event  
					person.stop = fates[event].stop  
					// Move the player's node to the jail square  
					places[11].node.append(person.node)  
					// Check if the player is bankrupt  
					checkBankrupt()  
					// Continue with the game sequence  
					gameSequence(s)  
				}, v * 1.5)  
			} else {  
				// If the event doesn't involve imprisonment  
				checkBankrupt()  
				gameSequence(s)  
			}  
			// Show a message box with the text of the event  
			showMsgbox(fates[event].text)  
		}   
		// If the player lands on an airport square (related to asynchronous behavior)  
		else if (place.state === "airport") {  
			// Determine the destination based on the airport's name  
			let des = place.name === "Baiyun Airport" ? "UK" : "China"  
			// Show a message box indicating that the player is taking a flight to the destination  
			showMsgbox(`You spent $800 to take a flight to ${des}`)  
			// After a delay (v * 1.5), execute the following block of code  
			setTimeout(() => {  
				// Calculate the new position based on the current position (assuming a total of 30 squares)  
				person.position = 30 - person.position  
				// Move the player's node to the new position  
				places[person.position].node.append(person.node)  
				// Check if the player is bankrupt  
				checkBankrupt()  
				// Continue with the game sequence  
				gameSequence(s)  
			}, v * 1.5)  
			// Deduct $800 from the player's money for the flight  
			person.money -= 800  
		}   
		// If the player lands on a trip square  
		else if (place.state === "trip") { // 旅游度假  
			// Generate a random number between 1 and 3 for the duration of the trip  
			person.stop = generateNum(1, 3)  
			// Deduct the cost of the trip from the person's money  
			person.money -= person.stop * 1000  
			// Display a message box showing the details of the trip    
			showMsgbox(`${person.name} expenditure ${person.stop * 1000} enjoy a travel holiday${person.stop}days`)  
			// Check if the person is bankrupt after the deduction  
			checkBankrupt()  
			// Continue the game sequence with the next step  
			gameSequence(s)  
		} 
	}, v * (num + 0.9))  // Calculated timing time
}

// Function to handle dialog clicks (for purchase or cancellation)  
function dialogClicked(type, action) { //   
	// Get the current place based on the person's position  
	let place = places[person.position]  
  
	// If no action is specified (close dialog): simulate NPC purchase decision  
	if (!action) { // 关闭对话框: 通过action模拟NPC购买与否  
		// Close the dialog box  
		closeDialog()  
		// Continue the game sequence  
		gameSequence(s)  
		// Exit the function  
		return  
	}  
  
	// If the type is "purchase"  
	if (type === "purchase") { 
		// Assign the place's owner to the person's name  
		place.owner = person.name 
		// Deduct the place's value from the person's money  
		person.money -= place.value  
		// Get the color associated with the person's name  
		let color = colorScheme[person.name]  
		// Call a function to show the ownership of the place  
		buyPlace(place.node, color, person.name)
		// Display a message box congratulating the person on their purchase  
		showMsgbox(`Congratulations on your win ${place.name}`)  
		// Continue the game sequence  
		gameSequence(s)  
	// If the type is not "purchase" (assumed to be "upgrade")  
	} else { // 升级  
		// Define an array of upgrade names  
		let upgradeMap = ["A small house", "A large villa", "A big hotel"]  
		// Deduct half the place's value from the person's money  
		person.money -= place.value / 2  
		// Increment the place's state (upgrade level)  
		place.state++  
		// Display a message box congratulating the person on their upgrade  
		showMsgbox(`Congratulations on your presence ${place.name} have built ${upgradeMap[place.state - 1]}`)  
		// Call a function to show the animation of the house upgrade   
		upgradeHouse(place.node, place.state - 1)  
	}  
  
	// Close the dialog box  
	closeDialog()  
	// Update the game's information or display  
	updateInfo()  
}  
  
// Function to generate a random number between a minimum and maximum value  
function generateNum(min, max) { // 生成随机数  
	// Use Math.random() to generate a random number between 0 and 1, multiply by (max - min), floor the result, and add min  
	return Math.floor(Math.random() * (max - min)) + min  
}

// Check related functions  
  
// Function to check if the next player in turn is in a stopped state  
function checkPlayerState(index) {  
	let player = players[index]; // Get the player object at the specified index  
	if (player.stop) { // If the player is in a stopped state   
		// Show a message indicating how many days the player has left in the stopped state  
		if (player.position === 11) {  
			showMsgbox(`${player.name} also have ${player.stop}days to get out`); // Show message for prison time  
		} else {  
			showMsgbox(`${player.name}, There are still ${player.stop} days left until the end of the rare holiday`); // Show message for vacation time  
		}  
		player.stop--; // Decrement the stop counter  
		return false; // Return false to indicate the player is stopped  
	} else if (player.state === "bankrupt") {  
		// If the player is bankrupt  
		return false; // Return false to indicate the player is bankrupt  
	} else {  
		// If the player is not stopped or bankrupt  
		if (!player.control) { // If it's an NPC's turn 
			// Set a timeout to call the game function for NPC action  
			setTimeout(() => {  
				game(); // Call the game function after a delay  
			}, v * 2); // Delay based on some variable v  
		} else { // If it's a player's turn and the dice is locked   
			// Toggle the dice to make it available for player action  
			toggleDice(true);  
		}  
		// Set the current player index for the next turn  
		s = index;  
		// Update the player's information on the screen  
		updatePlayer(player.name);  
		return true; // Return true to indicate the player can continue  
	}  
}  
  
// Function to check the win condition  
function checkFinish() {  
	let count = 0; // Variable to count active players  
	let winner; // Variable to store the winning player  
	players.forEach(player => { // Loop through all players to count active players   
		// Count the number of players in the "active" state  
		if (player.state === "active") {  
			count++;  
			winner = player; // Keep track of the last active player  
		}  
	});  
	if (count === 1) { // If only one person is active
		// Set a timeout to show the winner message and reload the page  
		setTimeout(() => {  
			alert(`${winner.name}win! Congratulations on being the richest man!`); // Show alert with winner message  
			location.reload(); // Reload the page  
		}, v * 2); // Delay based on some variable v  
	}  
}
// Judgment bankruptcy  
function checkBankrupt() {  
    // If the current player's money becomes negative  
    if (person.money < 0) { 
        // Set a timeout to perform the bankruptcy actions  
        setTimeout(() => {  
            // Set the stop counter to 0, indicating the player is not stopped  
            person.stop = 0;  
  
            // Set the player's state to bankrupt  
            person.state = "bankrupt";  
  
            // Alert the player that they have gone bankrupt and their properties will be confiscated  
            alert(`Unfortunately, ${person.name} has gone bankrupt, and all properties will be confiscated.`);  
  
            // Call a function to update the game state for the bankrupt player  
            updateBankrupt(person.node, players.indexOf(person), person.name);  
  
            // Hide the bankrupt player's UI box  
            $(`.box-${person.name.replace(' ', '')}`).hide();  
  
            // Iterate through all properties to confiscate those owned by the bankrupt player  
            // 地产充公  
            places.forEach(place => {   
                // If the property is owned by the bankrupt player  
                if (place.owner === person.name) {  
                    // Set the owner to empty string, indicating the property is now unowned  
                    place.owner = "";  
                    // Update the property's DOM node to reflect its confiscated state  
                    place.node.style.boxShadow = "1px 1px 1px inset #454545, 1px -1px 1px inset #454545, -1px 1px 1px inset #454545, -1px -1px 1px inset #454545";  
                }  
            });  
  
            // Check if the game has ended due to the player's bankruptcy  
            checkFinish(); 
        }, v / 2); // Set a delay based on some variable v  
    }  
}