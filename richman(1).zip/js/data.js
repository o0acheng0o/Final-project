/*
 * Store data, including character pieces, tiles, and chance fates
 */

// Preloaded picture
// Execute the following code when the window has finished loading
window.addEventListener('load', () => {
	// Initializes an empty array for storing image objects
	let images = []
	// Picture resource path array
	let src = [
		"./public/img/arrow.png", "./public/img/Patrick Star.png", "./public/img/Squidward_Tentacles.png", "./public/img/Mrs_Poppy Puff.png", "./public/img/Gary.png", "./public/img/Mr_Crab.png", "./public/img/Sandy Cheeks.png", "./public/img/Spongebob.png",
		"./public/img/1.jpg", "./public/img/2.jpg", "./public/img/3.jpg", "./public/img/4.jpg", "./public/img/5.jpg", "./public/img/6.jpg", "./public/img/s1.jpg", "./public/img/s2.jpg",
		"./public/img/c1.png", "./public/img/c2.png", "./public/img/c3.png", "./public/img/c4.png", "./public/img/c5.png", "./public/img/l1.png", "./public/img/l2.png", "./public/img/l3.png"
	]
	// Iterate through the array of Image paths, creating an image object for each path and setting its src attribute
	src.forEach((src, index) => {
		// Create a new Image object
		images[index] = new Image()
		// Set the src attribute of the Image object to the image path currently traversed
		images[index].src = src
	})
})

// game role
const roleList = [
	'Spongebob',
	'Patrick Star',
	'Squidward_Tentacles',
	'Mr_Crab',
	'Sandy Cheeks',
	'Gary',
	'Mrs_Poppy Puff',
]

// Different characters correspond to color schemes
var colorScheme = {
	"Spongebob": "#5E45AB",
	"Patrick Star": "#121212",
	"Squidward_Tentacles": "#274D7A",
	"Mr_Crab": "#B04E58",
	"Sandy Cheeks": "pink",
	"Gary": "#FA2A14",
	"Mrs_Poppy Puff": "#5FAE2E"
}


// Define roles
var players = [];

function CreatePlayer(name, index, money, state, stopDays, control, node) { // Create Player  
	this.name = name; // Name  
	this.index = index; // Order  
	this.money = money; // Money  
	this.state = state; // State: Active or Bankrupt  
	this.stopDays = stopDays; // Stop days  
	this.control = control; // Is controlled by player  
	this.node = node; // Corresponding DOM piece  
	this.position = 0; // Current position  
	players.push(this); // Add to array
}

// Box data  
var places = [];

function CreateBox(name, value, state, owner, index) { // Create Box  
	this.name = name; // Location name  
	this.value = value; // Value  
	this.state = state; // State: Special event / Level of ordinary property  
	this.owner = owner; // Owner / Special box  
	this.node = document.querySelectorAll('.map > div')[index]; // Corresponding DOM. 
	this.node.firstElementChild.textContent = name; // Append location name  
	places.push(this); // Add to array
}

// List of locations
const placeList = [
	["Start", 2000, 0, "", 18],
	["China", 5000, 0, "", 19],
	["Vietnam", 1000, 0, "", 20],
	["South Korea", 1300, 0, "", 21],
	["Chance", 1000, "surprise", "sean", 22],
	["Japan", 3000, 0, "", 23],
	["Russia", 4000, 0, "", 24],
	["Baiyun Airport", 1000, "airport", "sean", 25],
	["Pay Income Tax", 1000, "badEvent", "sean", 26],
	["Chance", 1000, "surprise", "sean", 27],
	["Egypt", 1600, 0, "", 28],
	["Jail", 0, "jail", "sean", 29],
	["Australia", 2400, 0, "", 17],
	["New Zealand", 1800, 0, "", 15],
	["Antarctica", 20000, 0, "", 13],
	["Casino", 1000, "casino", "sean", 11],
	["Chance", 1000, "surprise", "sean", 10],
	["Found Money", 1000, "goodEvent", "sean", 9],
	["Brazil", 2000, 0, "", 8],
	["Argentina", 2200, 0, "", 7],
	["Mexico", 2400, 0, "", 6],
	["United States", 4500, 0, "", 5],
	["Italy", 3000, 0, "", 4],
	["London Airport", 1000, "airport", "sean", 3],
	["United Kingdom", 3600, 0, "", 2],
	["Fate", 1000, "surprise", "sean", 1],
	["Alps", 1000, "trip", "sean", 0],
	["Germany", 3400, 0, "", 12],
	["France", 3200, 0, "", 14],
	["Spain", 2800, 0, "", 16]
]

// Chance and fate
var fates = []
function CreateFate(text, value, stop) { // Create opportunities and destiny
	this.text = text // Corresponding specification
	this.value = value // Change in money value
	this.stop = stop // Do I need to go to jail?
	fates.push(this) // Add to array
}

// definition fates list
const fatesList = [
	["Helped an old lady across the road, got a $1000 reward from the village committee", 1000, 0],
	["Won the lottery, got the jackpot of $5000", 5000, 0],
	["Got robbed on the street, lost $3000 to save my life", -3000, 0],
	["Bought a drink, spent $30", -30, 0],
	["Found $500 on the roadside", 500, 0],
	["Got a fishbone stuck in my throat, spent $800 at the hospital", -800, 0],
	["Left my wallet in a taxi, lost $1000", -1000, 0],
	["Did part-time tutoring in my free time, earned $2000", 2000, 0],
	["Helped an old lady across the road and fell, spent $100 on medicine", -100, 0],
	["My phone broke suddenly, replaced it with the latest iPhone, spent $1300", -1300, 0],
	["Had mutton hotpot, spent $500", -500, 0],
	["Went to Japan to see cherry blossoms, spent $2000", -2000, 0],
	["Nothing happened, except my wallet was $800 lighter", -800, 0],
	["Nothing happened, except my wallet was $1000 heavier", 1000, 0],
	["Did translation at the Canton Fair, earned $1000", 1000, 0],
	["Distributed flyers at the school gate, got $100", 100, 0],
	["Received a merit student scholarship of $3000", 3000, 0],
	["Grabbed a WeChat red envelope, got $1", 1, 0],
	["Dreamed of getting a $3000 reward, woke up and decided to spend $50 to worship gods", -50, 0],
	["Got a $3000 reward! Quickly spent $500 to fulfill a vow", 2500, 0],
	["Sold unused items and earned $100", 100, 0],
	["Nothing happened", 0, 0],
	["Watched a movie and spent $100", -100, 0],
	["Paid off a Huabei debt of $999", -999, 0],
	["Singles' Day arrived, spent $2000 on shopping", -2000, 0],
	["Suddenly felt thirsty and bought a bottle of mineral water, spent $5", -5, 0],
	["Went to a construction site to carry bricks and earned $500", 500, 0],
	["Got fined $1000 and detained for 1 day for tax evasion", -1000, 1],
	["Got fined $2000 and detained for 2 days for speeding", -2000, 2],
	["Got fined $1000 and detained for 3 days for illegal construction found by water meter inspection", -1000, 3],
	["Got detained for 5 days for cheating on an exam", 0, 5]
];

// Walk through the list of fates
fatesList.forEach(item => {
	// Generate a new fates 
	new CreateFate(...item);
});

// Get the current date in YYYY-MM-DD format  
function getDay() {
	// Create a new date object
	let date = new Date();
	// Get the current year  
	let year = date.getFullYear(); 
	// Get the current month (padded with zeros)  
	let month = String(date.getMonth() + 1).padStart(2, '0'); 
	// Get the current day (padded with zeros)  
	let day = String(date.getDate()).padStart(2, '0'); 
	// return date
	return `${year}-${month}-${day}`;
}

// China provincial and municipal data
const provinces = [
	{
		"name": "北京",
		"pinyin": "Beijing",
		"cities": [
			{
				"name": "北京市",
				"pinyin": "Beijing",
				"is_capital": true
			}
		]
	},
	{
		"name": "天津",
		"pinyin": "Tianjin",
		"cities": [
			{
				"name": "天津市",
				"pinyin": "Tianjin",
				"is_capital": true
			}
		]
	},
	{
		"name": "上海",
		"pinyin": "Shanghai",
		"cities": [
			{
				"name": "上海市",
				"pinyin": "Shanghai",
				"is_capital": true
			}
		]
	},
	{
		"name": "重庆",
		"pinyin": "Chongqing",
		"cities": [
			{
				"name": "重庆市",
				"pinyin": "Chongqing",
				"is_capital": true
			}
		]
	},
	{
		"name": "河北",
		"pinyin": "Hebei",
		"cities": [
			{
				"name": "石家庄市",
				"pinyin": "Shijiazhuang"
			},
			{
				"name": "唐山市",
				"pinyin": "Tangshan"
			},
			// ... other cities  
		]
	},
	{
		"name": "山西",
		"pinyin": "Shanxi",
		"cities": [
			{
				"name": "太原市",
				"pinyin": "Taiyuan"
			},
			{
				"name": "大同市",
				"pinyin": "Datong"
			},
			// ... other cities    
		]
	},
	{
		"name": "内蒙古",
		"pinyin": "Neimenggu",
		"cities": [
			{
				"name": "呼和浩特市",
				"pinyin": "Hohhot"
			},
			{
				"name": "包头市",
				"pinyin": "Baotou"
			},
			// ... other cities    
		]
	},
	// ... Other provinces  
	{
		"name": "广东",
		"pinyin": "Guangdong",
		"cities": [
			{
				"name": "广州市",
				"pinyin": "Guangzhou"
			},
			{
				"name": "深圳市",
				"pinyin": "Shenzhen"
			},
			// ... other cities    
		]
	},
	// ... Other provinces and municipalities  
]  